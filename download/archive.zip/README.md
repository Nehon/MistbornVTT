# Mistborn VTT

Custom and unnoficial Foundry VTT system for Crafty Game's Mistborn Adventure Game.
The system here implements the basics of mistborn but with custom house rules.
Probably not what you are looking for.
Use at your own risk.